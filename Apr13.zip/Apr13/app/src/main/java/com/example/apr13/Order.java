package com.example.apr13;

public class Order {
    public int orderId;
    public String emailAddress, itemName;
    public float itemPrice;
}
