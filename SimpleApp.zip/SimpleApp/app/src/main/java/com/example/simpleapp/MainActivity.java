package com.example.simpleapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void saveTask(View view) {
        EditText titleTextBox = findViewById(R.id.taskTitle);
        String taskName = titleTextBox.getText().toString();
        titleTextBox.setText("");
        //titleTextBox.getText().clear();

        EditText descriptionTextBox = findViewById((R.id.taskDescription));
        descriptionTextBox.setText(taskName);
    }
}