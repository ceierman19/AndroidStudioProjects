package dev.krupp.potpurri;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void showAlert(View view) {
        // Good to show a progress bar when the user tries to do something
        // You can toggle this by just setting the visibility
        final ProgressBar progressBar = findViewById(R.id.progressBar);
        progressBar.setVisibility(View.VISIBLE);

        // Also good to disable the button until a response is received
        final Button someButton = findViewById(R.id.someButton);
        someButton.setEnabled(false);

        // Good to show an error message (this can be used in an Error.Listener for your network request)
        // Use an AlertDialog Builder to create it:
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Network Error");
        builder.setMessage("Please check your network connection.");
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                progressBar.setVisibility(View.INVISIBLE);
                someButton.setEnabled(true);

                // A toast is a popup from the bottom that disappears (hence the name Toast!)
                Toast toast = Toast.makeText(getApplicationContext(), "You Tapped OK!", Toast.LENGTH_LONG);
                toast.show();
            }
        });
        builder.setNegativeButton("Disabled", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                progressBar.setVisibility(View.INVISIBLE);
                someButton.setEnabled(false);
            }
        });

        AlertDialog dialog = builder.create();
        dialog.show();
    }
}