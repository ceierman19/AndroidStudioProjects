package com.example.shoppinglist;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void saveItem(View view) {
        EditText itemTextBox = findViewById(R.id.itemTextBox);
        String itemName = itemTextBox.getText().toString();

        EditText listTextBox = findViewById((R.id.shopListTextBox));
        listTextBox.append(itemName + "\n");
    }
}