package com.example.someapp.model;

public class DateFormatRequest {
    public String format;

    public DateFormatRequest(String format) {
        this.format = format;
    }
}
