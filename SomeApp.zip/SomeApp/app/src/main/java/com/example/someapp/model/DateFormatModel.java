package com.example.someapp.model;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.example.someapp.ServiceClient;
import com.google.gson.Gson;

import org.json.JSONException;
import org.json.JSONObject;

public class DateFormatModel {
    public interface getDateFormatResponseHandler {
        void response(HostDate hostDate);
        void error();
    }

    public void getDateFormat(DateFormatRequest request, getDateFormatResponseHandler handler) {
        Gson gson = new Gson();
        String json = gson.toJson(request);

        JSONObject jsonObject = null;
        try {
            jsonObject = new JSONObject(json);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        JsonObjectRequest jsonRequest = new JsonObjectRequest(Request.Method.POST, "https://mopsdev.bw.edu/~bkrupp/330/examples/time.php", jsonObject, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                Gson gson = new Gson();
                HostDate hostDate = gson.fromJson(response.toString(), HostDate.class);
                handler.response(hostDate);
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                handler.error();
            }
        });
        ServiceClient client = ServiceClient.sharedServiceClient(null);
        client.addRequest(jsonRequest);
    }
}
