package com.example.someapp.model;

public class HostDate {
    public String hostname;
    public String date;

    public HostDate(String hostname, String date) {
        this.hostname = hostname;
        this.date = date;
    }
}
