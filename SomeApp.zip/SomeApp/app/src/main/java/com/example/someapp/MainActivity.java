package com.example.someapp;

import static java.lang.String.*;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.example.someapp.model.DateFormatModel;
import com.example.someapp.model.DateFormatRequest;
import com.example.someapp.model.HostDate;
import org.json.JSONException;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ServiceClient.sharedServiceClient(getApplicationContext());
        setContentView(R.layout.activity_main);
    }

    public void clicked(View view) {
        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, "https://mopsdev.bw.edu/~bkrupp/330/examples/time.php", null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                int seconds = 0;
                try {
                    seconds = response.getInt("time");
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                TextView timeField = findViewById(R.id.currentTime);
                timeField.setText(format("%d", seconds));
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                int x = 5;
            }
        });
        ServiceClient client = ServiceClient.sharedServiceClient(getApplicationContext());
        client.addRequest(request);
    }

    public void clicked2(View view) {
        DateFormatRequest requestObject = new DateFormatRequest("F d Y h:i");
        DateFormatModel model = new DateFormatModel();
        model.getDateFormat(requestObject, new DateFormatModel.getDateFormatResponseHandler() {
            @Override
            public void response(HostDate hostDate) {
                TextView textView = findViewById(R.id.currentTime);
                textView.setText(hostDate.date + hostDate.hostname);
            }

            @Override
            public void error() {
                //TODO: Handle error
            }
        });
    }
}