package com.example.activityintentlab;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class WelcomeActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome);

        Intent intent = getIntent();
        String name = intent.getStringExtra("name");

        TextView welcomeHeader = findViewById(R.id.welcomeHeader);
        welcomeHeader.setText("Welcome " + name);
    }

    public void makeReservations(View view) {
        Intent intent = getIntent();
        String name = intent.getStringExtra("name");

        Intent intent2 = new Intent(this, ReservationActivity.class);
        intent2.putExtra("name", name);
        startActivity(intent2);
    }

    public void leaveReview(View view) {
        Intent intent = getIntent();
        String name = intent.getStringExtra("name");

        Intent intent2 = new Intent(this, ReviewActivity.class);
        intent2.putExtra("name", name);
        startActivity(intent2);
    }
}