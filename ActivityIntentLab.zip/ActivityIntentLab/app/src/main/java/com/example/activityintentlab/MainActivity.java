package com.example.activityintentlab;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void register(View view) {
        EditText nameField = findViewById(R.id.editTextName);
        String name = nameField.getText().toString();

        EditText emailField = findViewById(R.id.editTextEmail);
        String email = emailField.getText().toString();

        EditText phoneField = findViewById(R.id.editTextPhone);
        String phone = phoneField.getText().toString();

        if (!name.isEmpty() && !email.isEmpty() && !phone.isEmpty()) {
            Intent intent = new Intent(this, WelcomeActivity.class);
            intent.putExtra("name", name);
            startActivity(intent);
        }
        else {
            Toast toast = Toast.makeText(this, "Please enter a name, email, and phone number.", Toast.LENGTH_LONG);
            toast.show();
        }
    }
}