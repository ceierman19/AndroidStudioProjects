package com.example.activityintentlab;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class ReviewActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_review);

        Intent intent = getIntent();
        String name = intent.getStringExtra("name");

        TextView reviewHeader = findViewById(R.id.reviewHeader);
        reviewHeader.setText("Welcome " + name);
    }

    public void completeReview(View view) {
        EditText reviewRestaurantNameField = findViewById(R.id.editTextReviewRestaurantName);
        String reviewRestaurantName = reviewRestaurantNameField.getText().toString();

        EditText reviewField = findViewById(R.id.editTextReview);
        String review = reviewField.getText().toString();

        if (!reviewRestaurantName.isEmpty() && !review.isEmpty()) {
            finish();
        }
        else {
            Toast toast = Toast.makeText(this, "Please enter a restaurant name, rating, and review.", Toast.LENGTH_LONG);
            toast.show();
        }
    }

    public void finish() {
        Intent intent = getIntent();
        String name = intent.getStringExtra("name");

        Intent intent2 = new Intent(this, WelcomeActivity.class);
        intent2.putExtra("name", name);
        startActivity(intent2);
    }
}