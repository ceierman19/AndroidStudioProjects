package com.example.activityintentlab;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class ReservationActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reservation);

        Intent intent = getIntent();
        String name = intent.getStringExtra("name");

        TextView reservationHeader = findViewById(R.id.reservationHeader);
        reservationHeader.setText("Welcome " + name);
    }

    public void completeReservation(View view) {
        EditText restaurantNameField = findViewById(R.id.editTextRestaurantName);
        String restaurantName = restaurantNameField.getText().toString();

        EditText timeField = findViewById(R.id.editTextTime);
        String time = timeField.getText().toString();

        if (!restaurantName.isEmpty() && !time.isEmpty()) {
            finish();
        }
        else {
            Toast toast = Toast.makeText(this, "Please enter a restaurant name and time.", Toast.LENGTH_LONG);
            toast.show();
        }
    }

    public void finish() {
        Intent intent = getIntent();
        String name = intent.getStringExtra("name");

        Intent intent2 = new Intent(this, WelcomeActivity.class);
        intent2.putExtra("name", name);
        startActivity(intent2);
    }
}