package com.example.recyclerviewexample.Model;

import com.example.recyclerviewexample.ToDo;

import java.util.ArrayList;
import java.util.List;

public class ToDoModel {
    private List<ToDo> todos = new ArrayList<>();

    public ToDoModel() {
        // Test data
        // TODO: Remove
        for(int i = 0; i < 16; i++) {
            addToDo(new ToDo(i, String.format("%d To Do", i)));
        }
    }

    public void addToDo(ToDo todo) {
        todos.add(todo);
    }

    public int getCount() {
        return todos.size();
    }

    public List<ToDo> getItems() {
        return todos;
    }
}
