package com.example.recyclerviewexample;

public class ToDo {
    int priority;
    String toDo;

    public ToDo(int priority, String toDo) {
        this.priority = priority;
        this.toDo = toDo;
    }
}
